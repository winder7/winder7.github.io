/*Autores: Jackson Veloso - Python
           Winder Rezende - Java
*/
import java.util.Scanner;

public class CalculoSubRedes {

    public static void main(String[] args){
	Scanner leia = new Scanner (System.in);
        String IP;
        String[] Oct;
	int Bit, Hosts, Cont=0;
        int[] Broad = new int[4], Rede = new int[4], OctInt = new int[4];
        
        System.out.println("((<<----------------Calculo de Sub-redes | Projeto Integrador 01/2017-------------->>))");
        
        do{
            System.out.print("  -> Digite o endereço de IP desejado: ");
            IP =  leia.next();
            
            Oct = IP.split("\\.");
            if (Oct.length != 4){
                System.out.println("IP inválido! Digite Novamente...");  
            }  
        }while(Oct.length != 4);
        
        do{        
            System.out.print("\n  Por favor, digite o prefixo da rede: /");
            Bit = leia.nextInt();
            if(Bit<8 || Bit>30){
                System.out.println("  Prefixo invalido! Digite Novamente");
            }
        }while(Bit<8 || Bit>30);

        int mask[] = {0,0,0,0};
	for (int i = 0; i < Bit; i++) {     
            mask[i/8] = mask[i/8] + (1 << (7 - i % 8));
        }
      
        for (int i=0; i < 4; i++){
            OctInt[i] = Integer.parseInt(Oct[i]);
            Rede[i] = OctInt[i] & mask[i];
            Broad[i] = Rede[i];
        }
        
        int brange = 32 - Bit;
        for (int i=0; i < brange; i++){
        Broad[3 - i/8] = Broad[3 - i/8] + (1 << (i % 8));
        }
        
        Hosts = (int) Math.pow(2, brange);
        
        System.out.println("\n-----------------------------------Resultados:---------------------------------------");
        System.out.print("Endereço....................: "+IP);
        
        if (OctInt[0] >1 && OctInt[0]<=127) {
            System.out.print(" Classe A\n");   
        }
        else if (OctInt[0] >=128 && OctInt[0]<=191) {
            System.out.print(" Classe B\n");
        }
        else if (OctInt[0] >=192 && OctInt[0]<=223) {
            System.out.print(" Classe C\n");
        }
        else if (OctInt[0] >=224 && OctInt[0]<=239) {
            System.out.print(" Classe D\n");
        }
        else if (OctInt[0] >=240 && OctInt[0]<=255) {
            System.out.print(" Classe E\n");
        }
        
        System.out.println("Rede........................: "+Rede[0]+"."+Rede[1]+"."+Rede[2]+"."+Rede[3]);
        System.out.println("Broadcast...................: "+Broad[0]+"."+Broad[1]+"."+Broad[2]+"."+Broad[3]);
        System.out.println("Mascara.....................: "+mask[0]+"."+mask[1]+"."+mask[2]+"."+mask[3]);
        System.out.println("Hosts usáveis por sub-rede..: "+(Hosts-2));
        System.out.println("-------------------------------------------------------------------------------------");
        
        if (Bit >=24 && Bit <=30 && OctInt[0]<=223){
            Rede[3] = 0;
            Broad[3] = Hosts-1;
            System.out.println("\n----------------------------------Tabela de Sub-Redes--------------------------------");
            while(Broad[3]<=255){
                Cont++;
                System.out.print(Cont+"ª Sub-rede: "+Rede[0]+"."+Rede[1]+"."+Rede[2]+"."+Rede[3]+" | Hosts: ");
                Rede[3]=Rede[3] + 1;
                System.out.print(Rede[0]+"."+Rede[1]+"."+Rede[2]+"."+Rede[3]+" à ");
                Broad[3] = Broad[3] -1;
                System.out.print(Broad[3]+" | Broadcast: ");
                Broad[3] = Broad[3] +1;
                System.out.print(Broad[0]+"."+Broad[1]+"."+Broad[2]+"."+Broad[3]+"\n");
                Rede[3] = (int) ((Rede[3] -1 ) + Hosts);
                Broad[3] = (int) ((Broad[3]) + Hosts);
                System.out.println("-------------------------------------------------------------------------------------");
            }   
            System.out.println(" Digite o codigo da subrede desejada:");
        }
    }
}