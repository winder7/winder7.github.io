import java.util.Scanner;

/* @Autores: Alex, Jheniffer, Victor e Winder.
 * GTI 1 - Senac - Projeto Integrador 01/2017*/


public class ProjetoIntegrador {
            
    public static void main(String[] args) {
        // Variáveis
        Scanner leia = new Scanner (System.in);  
        String IP, Barra, BinRede, BinBroadcast; 
        String[] BitRede = {"00000000","0000000","000000","00000","0000","000","00","0",""};
        String[] BitBroadcast = {"11111111","1111111","111111","11111","1111","111","11","1",""};
        String[] StrOctetos, BinOctetos = new String[4], BinOcts8c = new String[4];
        String[] Mascara = {"255.0.0.0","255.128.0.0","255.192.0.0","255.224.0.0","255.240.0.0","255.248.0.0","255.252.0.0","255.254.0.0","255.255.0.0",
                            "255.255.128.0","255.255.192.0","255.255.224.0","255.255.240.0","255.255.248.0","255.255.252.0","255.255.254.0","255.255.255.0",
                            "255.255.255.128","255.255.255.192","255.255.255.224","255.255.255.240","255.255.255.248","255.255.255.252"};
        int Pref, NumRede, NumBroadcast,Cont=0, Hosts=0, Subredes=0; 
        int[] IntOctetos = new int[4];
            
        System.out.println("\n((<<--------------Calculo de Sub-redes | Projeto Integrador 01/2017-------------->>))");
        do{
            do{
                System.out.print("  -> Digite o endereco de IP desejado: ");
                IP = leia.next();
                StrOctetos = IP.split("\\.");
                if (StrOctetos.length != 4){
                System.out.println("  IP invalido! Digite Novamente...");
                 }
            }while(StrOctetos.length != 4);
        
            for (int i = 0; i < 4; i++) {
                IntOctetos[i] = Integer.parseInt(StrOctetos[i]); 
            }
            
            if (IntOctetos[0]<1 || IntOctetos[0]>255 || IntOctetos[1]<0 || IntOctetos[1]>255 || IntOctetos[2]<0 || IntOctetos[2]>255 || IntOctetos[3]<0 || IntOctetos[3]>255){
                System.out.println("  IP invalido! Digite Novamente...");
            }
        }while(IntOctetos[0]<1 || IntOctetos[0]>255 || IntOctetos[1]<0 || IntOctetos[1]>255 || IntOctetos[2]<0 || IntOctetos[2]>255 || IntOctetos[3]<0 || IntOctetos[3]>255);
        
        for (int i = 0; i < 4; i++) {
            BinOctetos[i] = Integer.toBinaryString(IntOctetos[i]); 
            BinOcts8c[i] = String.format ("%08d", Integer.parseInt(BinOctetos[i])); 
        }
        
        do{
            System.out.print("\n  -> Por favor, digite o prefixo da rede: /");
            Pref = leia.nextInt();
            if (Pref<8 || Pref>30) {
                System.out.println("  Prefixo invalido! Digite Novamente");
            }
            else if(Pref<23 && IntOctetos[0]>191){
                System.out.println("  Prefixo invalido! IP Classe C prefixo deve ser maior ou igual a 24");
            }
        }while(Pref<8 || Pref>30 || (Pref<24 && IntOctetos[0]>191)); 
        
        System.out.println("\n-----------------------------------Resultados:---------------------------------------");
        System.out.print("Endereco....................: "+IP);    
        if (IntOctetos[0] >=1 && IntOctetos[0]<=127) { 
            System.out.print(" Classe A\n");   
        }
        else if (IntOctetos[0] >=128 && IntOctetos[0]<=191) {
            System.out.print(" Classe B\n");
        }
        else if (IntOctetos[0] >=192 && IntOctetos[0]<=223) {
            System.out.print(" Classe C\n");
        }
        else if (IntOctetos[0] >=224 && IntOctetos[0]<=239) {
            System.out.print(" Classe D\n");
        }
        else if (IntOctetos[0] >=240 && IntOctetos[0]<=255) {
            System.out.print(" Classe E\n");
        }
  
        if(Pref>=8 && Pref<=15){ 
            Barra = BinOcts8c[1].substring(0, Pref-8); 
            BinRede = Barra+BitRede[Pref-8]; 
            BinBroadcast = Barra+BitBroadcast[Pref-8]; 
            NumRede = Integer.parseInt(BinRede, 2); 
            NumBroadcast = Integer.parseInt(BinBroadcast, 2); 
            System.out.println("Rede........................: "+IntOctetos[0]+"."+NumRede+".0.0"); 
            System.out.println("Broadcast...................: "+IntOctetos[0]+"."+NumBroadcast+".255.255"); 
            System.out.println("Mascara.....................: "+Mascara[Pref-8]); 
            Hosts = (int) Math.pow(2, (32-Pref)); 
            Subredes = (int) Math.pow(2, (24-(32-Pref))); 
            System.out.println("Hosts usaveis por sub-rede..: "+(Hosts-2));
            System.out.println("Total de sub-redes..........: "+Subredes);
            System.out.println("-------------------------------------------------------------------------------------");
            System.out.println("\nPara calcular a tabela de Sub-Redes digite um IP Classe C");
        }
        else if(Pref>=16 && Pref<=23){ 
            Barra = BinOcts8c[2].substring(0, Pref-16);
            BinRede = Barra+BitRede[Pref-16];
            BinBroadcast = Barra+BitBroadcast[Pref-16];
            NumRede = Integer.parseInt(BinRede, 2);
            NumBroadcast = Integer.parseInt(BinBroadcast, 2);
            System.out.println("Rede........................: "+IntOctetos[0]+"."+IntOctetos[1]+"."+NumRede+".0");
            System.out.println("Broadcast...................: "+IntOctetos[0]+"."+IntOctetos[1]+"."+NumBroadcast+".255");
            System.out.println("Mascara.....................: "+Mascara[Pref-8]);
            Hosts = (int) Math.pow(2, (32-Pref));
            Subredes = (int) Math.pow(2, (16-(32-Pref)));
            System.out.println("Hosts usaveis por sub-rede..: "+(Hosts-2));
            System.out.println("Total de sub-redes..........: "+Subredes);
            System.out.println("-------------------------------------------------------------------------------------");
            System.out.println("\nPara calcular a tabela de Sub-Redes digite um IP Classe C");
        }
        else if(Pref>=24 && Pref<=30){ 
            Barra = BinOcts8c[3].substring(0, Pref-24);
            BinRede = Barra+BitRede[Pref-24];
            BinBroadcast = Barra+BitBroadcast[Pref-24];
            NumRede = Integer.parseInt(BinRede, 2);
            NumBroadcast = Integer.parseInt(BinBroadcast, 2);
            System.out.println("Rede........................: "+IntOctetos[0]+"."+IntOctetos[1]+"."+IntOctetos[2]+"."+NumRede);
            System.out.println("Broadcast...................: "+IntOctetos[0]+"."+IntOctetos[1]+"."+IntOctetos[2]+"."+NumBroadcast);
            System.out.println("Mascara.....................: "+Mascara[Pref-8]);
            Hosts = (int) Math.pow(2, (32-Pref));
            Subredes = (int) Math.pow(2, (8-(32-Pref)));
            System.out.println("Hosts usaveis por sub-rede..: "+(Hosts-2));
            System.out.println("Total de sub-redes..........: "+Subredes);
            System.out.println("-------------------------------------------------------------------------------------");
            NumRede = 0;
            NumBroadcast = Hosts-1;
            if(IntOctetos[0] >=192 && IntOctetos[0]<=223){ 
                System.out.println("\n----------------------------------Tabela de Sub-Redes--------------------------------");
                while(NumBroadcast<=255){ 
                    Cont++;
                    System.out.print(Cont+". Sub-rede: "+IntOctetos[0]+"."+IntOctetos[1]+"."+IntOctetos[2]+"."+NumRede+" | Hosts: ");
                    NumRede=NumRede + 1;
                    System.out.print(IntOctetos[0]+"."+IntOctetos[1]+"."+IntOctetos[2]+"."+NumRede+" a ");
                    NumBroadcast = NumBroadcast -1;
                    System.out.print(NumBroadcast+" | Broadcast: ");
                    NumBroadcast = NumBroadcast +1;
                    System.out.print(IntOctetos[0]+"."+IntOctetos[1]+"."+IntOctetos[2]+"."+NumBroadcast+"\n");
                    NumRede = (int) ((NumRede -1 ) + Hosts);
                    NumBroadcast = (int) ((NumBroadcast) + Hosts);
                    System.out.println("-------------------------------------------------------------------------------------");
                }
            }
            else{
                System.out.println("\nPara calcular a tabela de Sub-Redes digite um IP Classe C");
            }
        }      
    }          
}        